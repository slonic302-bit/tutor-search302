#!/usr/bin/env python3
"""
Миграция для добавления поля photo_url в таблицу tutor_profile
"""

import sqlite3
import os

def migrate_database():
    db_path = 'instance/app_new.db'
    
    if not os.path.exists(db_path):
        print(f"База данных {db_path} не найдена")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Проверяем, существует ли колонка photo_url
        cursor.execute("PRAGMA table_info(tutor_profile)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'photo_url' not in columns:
            print("Добавление колонки photo_url...")
            cursor.execute("ALTER TABLE tutor_profile ADD COLUMN photo_url TEXT")
            conn.commit()
            print("Колонка photo_url успешно добавлена")
        else:
            print("Колонка photo_url уже существует")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"Ошибка миграции: {e}")
        return False

if __name__ == "__main__":
    if migrate_database():
        print("Миграция выполнена успешно")
    else:
        print("Ошибка при выполнении миграции")
