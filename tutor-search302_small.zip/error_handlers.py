from flask import jsonify, render_template
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class APIError(Exception):
    """Базовый класс для API ошибок"""
    def __init__(self, message, status_code=400, payload=None):
        super().__init__()
        self.message = message
        self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['error'] = self.message
        return rv

class ValidationError(APIError):
    """Ошибка валидации"""
    def __init__(self, message, field=None):
        super().__init__(message, 400)
        self.field = field

class AuthenticationError(APIError):
    """Ошибка аутентификации"""
    def __init__(self, message='Требуется аутентификация'):
        super().__init__(message, 401)

class AuthorizationError(APIError):
    """Ошибка авторизации"""
    def __init__(self, message='Недостаточно прав'):
        super().__init__(message, 403)

class NotFoundError(APIError):
    """Ресурс не найден"""
    def __init__(self, message='Ресурс не найден'):
        super().__init__(message, 404)

class ConflictError(APIError):
    """Конфликт данных"""
    def __init__(self, message='Конфликт данных'):
        super().__init__(message, 409)

class RateLimitError(APIError):
    """Превышен лимит запросов"""
    def __init__(self, message='Слишком много запросов'):
        super().__init__(message, 429)

def handle_api_error(error):
    """Обработчик API ошибок"""
    logger.error(f'API Error: {error.message} - Status: {error.status_code}')
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response

def handle_validation_error(error):
    """Обработчик ошибок валидации"""
    logger.warning(f'Validation Error: {error.message} - Field: {error.field}')
    response = jsonify({
        'error': error.message,
        'field': error.field
    })
    response.status_code = 400
    return response

def handle_generic_error(error):
    """Обработчик общих ошибок"""
    logger.error(f'Unhandled Error: {str(error)}', exc_info=True)
    
    if request.path.startswith('/api/'):
        response = jsonify({'error': 'Внутренняя ошибка сервера'})
        response.status_code = 500
        return response
    
    return render_template('500.html', error=error), 500

def setup_error_handlers(app):
    """Настройка обработчиков ошибок для Flask приложения"""
    
    # API ошибки
    @app.errorhandler(APIError)
    def api_error_handler(error):
        return handle_api_error(error)
    
    @app.errorhandler(ValidationError)
    def validation_error_handler(error):
        return handle_validation_error(error)
    
    # HTTP ошибки
    @app.errorhandler(400)
    def bad_request(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Неверный запрос'}), 400
        return render_template('400.html'), 400
    
    @app.errorhandler(401)
    def unauthorized(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Требуется аутентификация'}), 401
        return render_template('401.html'), 401
    
    @app.errorhandler(403)
    def forbidden(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Доступ запрещен'}), 403
        return render_template('403.html'), 403
    
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Ресурс не найден'}), 404
        return render_template('404.html'), 404
    
    @app.errorhandler(429)
    def rate_limit(error):
        if request.path.startswith('/api/'):
            return jsonify({'error': 'Слишком много запросов'}), 429
        return render_template('429.html'), 429
    
    @app.errorhandler(500)
    def internal_error(error):
        return handle_generic_error(error)

# Декораторы для валидации
def validate_json(required_fields=None, optional_fields=None):
    """Декоратор для валидации JSON данных"""
    def decorator(f):
        def wrapper(*args, **kwargs):
            from flask import request
            
            if not request.is_json:
                raise ValidationError('Ожидаются JSON данные')
            
            data = request.get_json() or {}
            
            # Проверка обязательных полей
            if required_fields:
                for field in required_fields:
                    if field not in data or not data[field]:
                        raise ValidationError(f'Поле {field} обязательно', field)
            
            # Проверка типов данных
            if optional_fields:
                for field, field_type in optional_fields.items():
                    if field in data and data[field] is not None:
                        try:
                            if field_type == int:
                                data[field] = int(data[field])
                            elif field_type == float:
                                data[field] = float(data[field])
                            elif field_type == bool:
                                data[field] = bool(data[field])
                        except (ValueError, TypeError):
                            raise ValidationError(f'Поле {field} должно быть типа {field_type.__name__}', field)
            
            return f(*args, **kwargs)
        return wrapper
    return decorator

def rate_limit(max_requests=100, window=3600):
    """Декоратор для ограничения частоты запросов (простая реализация)"""
    # В реальном приложении здесь должна быть Redis или другая система кэширования
    requests = {}
    
    def decorator(f):
        def wrapper(*args, **kwargs):
            from flask import request
            
            client_ip = request.remote_addr
            now = datetime.now().timestamp()
            
            # Очистка старых записей
            if client_ip in requests:
                requests[client_ip] = [req_time for req_time in requests[client_ip] 
                                     if now - req_time < window]
            else:
                requests[client_ip] = []
            
            # Проверка лимита
            if len(requests[client_ip]) >= max_requests:
                raise RateLimitError(f'Превышен лимит в {max_requests} запросов за {window} секунд')
            
            requests[client_ip].append(now)
            return f(*args, **kwargs)
        return wrapper
    return decorator
