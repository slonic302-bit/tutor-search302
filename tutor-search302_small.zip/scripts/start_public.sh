#!/usr/bin/env bash
set -euo pipefail

# Запускает приложение и туннель ngrok, чтобы сайт был доступен из интернета.
# Работает из корня репозитория.

# Путь к Python в виртуальном окружении (если он есть)
PYTHON=${PYTHON:-"./.venv/bin/python"}

# Порт, на котором будет работать Flask
PORT=${PORT:-5000}

# Убедимся, что flask проект запускается на 0.0.0.0
export FLASK_RUN_HOST=0.0.0.0
export FLASK_RUN_PORT=$PORT

# Запуск приложения
echo "[1/2] Запускаем Flask-приложение на порту $PORT..."
# Запускаем в фоне, чтобы продолжать
"$PYTHON" app.py &
APP_PID=$!

# Небольшая пауза, чтобы приложение успело стартануть
sleep 2

# Запуск ngrok
echo "[2/2] Запускаем ngrok (туннель) в порт $PORT..."
./scripts/run_ngrok.sh "$PORT" &
NGROK_PID=$!

echo
echo "✅ Запущено."
echo "PID Flask: $APP_PID"
echo "PID ngrok: $NGROK_PID"

echo "
Чтобы остановить: kill $APP_PID $NGROK_PID"

echo "Откройте ngrok URL в браузере (будет показан в выводе ngrok)."

wait $NGROK_PID
