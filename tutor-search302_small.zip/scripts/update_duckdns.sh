#!/usr/bin/env bash
set -euo pipefail

# Скрипт обновляет IP записи duckdns.org для домена slon--russ.duckdns.org
# Перед запуском задайте переменную окружения DUCKDNS_TOKEN.

DOMAIN="slon--russ"
TOKEN="${DUCKDNS_TOKEN:-}"

if [[ -z "$TOKEN" ]]; then
  echo "ERROR: set DUCKDNS_TOKEN environment variable (https://www.duckdns.org)"
  exit 1
fi

# Обновление IP (по умолчанию используется текущий публичный IP)
URL="https://www.duckdns.org/update?domains=$DOMAIN&token=$TOKEN&ip="

echo "Updating duckdns for $DOMAIN..."
RESPONSE=$(curl -s "$URL")
if [[ "$RESPONSE" == "OK" ]]; then
  echo "DuckDNS updated successfully"
else
  echo "DuckDNS update failed: $RESPONSE"
  exit 1
fi
