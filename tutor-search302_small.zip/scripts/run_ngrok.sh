#!/usr/bin/env bash
set -euo pipefail

PORT=${1:-5000}

# Путь к бинарнику ngrok в репозитории (локально)
NGROK_BIN="$(pwd)/.ngrok/ngrok"

mkdir -p ".ngrok"

if [[ ! -x "$NGROK_BIN" ]]; then
  echo "ngrok не найден. Скачиваем..."

  # Определяем архитектуру
  ARCH=$(uname -m)
  case "$ARCH" in
    x86_64) NGROK_ARCH="amd64" ;;
    aarch64|arm64) NGROK_ARCH="arm64" ;;
    *)
      echo "Неизвестная архитектура: $ARCH"
      echo "Скачайте ngrok вручную с https://ngrok.com/download"
      exit 1
      ;;
  esac

  URL="https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-$NGROK_ARCH.zip"
  TMPZIP="/tmp/ngrok.zip"
  curl -sSL "$URL" -o "$TMPZIP"
  unzip -o "$TMPZIP" -d ".ngrok"
  chmod +x "$NGROK_BIN"
  rm -f "$TMPZIP"
  echo "ngrok установлен в $NGROK_BIN"
fi

# Если задан токен, автоматически авторизуемся (нужно для работы ngrok)
if [[ -n "${NGROK_AUTHTOKEN:-}" ]]; then
  echo "Настройка ngrok authtoken..."
  "$NGROK_BIN" authtoken "$NGROK_AUTHTOKEN" 2>/dev/null || true
  echo "Authtoken настроен."
else
  echo "⚠️ Внимание: NGROK_AUTHTOKEN не задан. ngrok будет работать только в ограниченном режиме и может падать."
  echo "Получить токен: https://dashboard.ngrok.com/get-started/your-authtoken"
fi

echo "Запускаем ngrok на порту $PORT..."
echo "После запуска откройте публичный URL, который выдаст ngrok."

"$NGROK_BIN" http "$PORT"
