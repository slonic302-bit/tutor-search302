# EduNext - Платформа онлайн-репетиторства

Современная веб-платформа для поиска репетиторов и записи на курсы подготовки к экзаменам.

## 🚀 Возможности

- **Поиск репетиторов** по предметам, цене и опыту
- **Онлайн-курсы** для подготовки к ЕГЭ и ОГЭ
- **Система отзывов** и рейтингов
- **Личные кабинеты** для студентов и репетиторов
- **Сообщения** между пользователями
- **Админ-панель** для управления платформой

## 🛠️ Технологии

- **Backend**: Flask, SQLAlchemy, Flask-Login
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Database**: SQLite (разработка), PostgreSQL (продакшен)
- **Security**: CSRF защита, валидация данных, хеширование паролей

## 📦 Установка и запуск

### Требования
- Python 3.8+
- pip

### Установка
```bash
# Клонирование репозитория
git clone <repository-url>
cd FlaskProject

# Создание виртуального окружения
python -m venv venv

# Активация окружения
# Windows:
venv\\Scripts\\activate
# Linux/Mac:
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt
```

### Конфигурация
```bash
# Создание файла переменных окружения
cp .env.example .env

# Редактирование .env файла
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///app.db
FLASK_ENV=development
```

### Запуск
```bash
# Инициализация базы данных
python seed_demo.py

# Запуск приложения
python app.py
```

Приложение будет доступно по адресу: http://localhost:5000

### 🚀 Публичный доступ через ngrok (поделиться ссылкой с кем угодно)
Теперь есть удобный скрипт, который запускает сразу и приложение, и туннель.

```bash
./scripts/start_public.sh
```

После запуска:
- Приложение будет работать локально на `http://localhost:5000`.
- В терминале ngrok покажет публичный URL вроде `https://abcd1234.ngrok.io` — его можно отправлять любому.

> **Важно:** ngrok требует **authtoken**. Без него tunnel может падать.
> Получите токен на https://dashboard.ngrok.com/get-started/your-authtoken

Установите токен так:
```bash
export NGROK_AUTHTOKEN="ваш_токен"
```

Если хотите запускать только туннель (приложение уже работает), используйте:
```bash
./scripts/run_ngrok.sh 5000
```

## 🌐 Доступ по домену (duckdns)
Если вы хотите, чтобы сайт работал по домену `slon--russ.duckdns.org`, используйте DuckDNS и обратный прокси.

### 1) Настроить DuckDNS
1. Зарегистрируйтесь / войдите на https://www.duckdns.org/
2. Создайте домен `slon--russ`
3. Скопируйте токен и сохраните его (он понадобится ниже)

### 2) Обновление IP (скрипт)
```bash
export DUCKDNS_TOKEN="<ваш_токен>"
./scripts/update_duckdns.sh
```

### 3) Запустить приложение в Docker + nginx
```bash
# Собираем образ и поднимаем сервисы
docker compose build

docker compose up -d
```

### 4) Выполнить получение сертификата Let's Encrypt
> После этого шага nginx сможет обслуживать HTTPS.

1) Убедитесь, что домен `slon--russ.duckdns.org` резолвится в ваш IP и порты 80/443 открыты.
2) Запустите команду для получения сертификата:
```bash
docker compose run --rm certbot certonly \
  --webroot -w /var/www/certbot \
  --agree-tos --no-eff-email \
  --email your-email@example.com \
  -d slon--russ.duckdns.org
```

3) Перезапустите nginx чтобы он подхватил новые сертификаты:
```bash
docker compose restart nginx
```

Сайт будет доступен по адресу:
- http://slon--russ.duckdns.org (перенаправление на HTTPS)
- https://slon--russ.duckdns.org (рабочий HTTPS)

> 🔥 Если вы меняете IP, просто запустите `./scripts/update_duckdns.sh` и перезапустите `docker compose restart nginx`.

## 🏗️ Структура проекта

```
FlaskProject/
├── app.py              # Основное приложение Flask
├── config.py           # Конфигурации приложения
├── error_handlers.py   # Обработчики ошибок
├── requirements.txt    # Зависимости Python
├── seed_demo.py       # Инициализация базы данных
├── templates/         # HTML шаблоны
│   ├── base.html     # Базовый шаблон
│   ├── index.html    # Главная страница
│   ├── *.html        # Другие шаблоны
└── instance/         # База данных SQLite
```

## 🔐 Безопасность

Приложение включает следующие меры безопасности:

- **CSRF защита** для всех форм
- **Валидация email** и паролей
- **Хеширование паролей** с помощью Werkzeug
- **Защита от SQL-инъекций** через SQLAlchemy ORM
- **Ограничение частоты запросов** (Rate Limiting)
- **Безопасные заголовки** HTTP

## 🚀 Продакшен развертывание

### 📦 Через Docker (рекомендуется)
Проект уже содержит `Dockerfile` и `docker-compose.yml`. Это самый простой способ запустить сайт на хостинге, который поддерживает Docker (Render, Railway, VPS и т.д.).

```bash
# Собрать образ
docker compose build

# Запустить контейнеры
docker compose up -d
```

### 🐘 Через PostgreSQL (рекомендуем для продакшена)
Для стабильной работы в продакшене лучше использовать PostgreSQL, а не SQLite (SQLite не подходит для распределённых окружений).

```bash
export DATABASE_URL=postgresql://user:password@localhost/edunext
export SECRET_KEY=your-production-secret-key
export FLASK_ENV=production
```

### 🚀 Развертывание на Render.com (под ключ)
1) Запушьте проект в GitHub.
2) Создайте новый Web Service в Render и выберите "Docker".
3) Укажите `Dockerfile` как путь.
4) В разделе Environment Variables задайте:
- `SECRET_KEY` — любой длинный секрет
- `DATABASE_URL` — например, `sqlite:///instance/app_new.db` (или PostgreSQL)
- `FLASK_ENV` — `production`

(Render автоматически запускает сборку и стартует сервис.)

> Для Render вы можете использовать файл `render.yaml` (он уже есть в репозитории).

### ✈️ Развертывание на Fly.io (бесплатный вариант)
Fly.io позволяет поднимать контейнеры и автоматически получает HTTPS.

1) Установите `flyctl`: https://fly.io/docs/hands-on/install-fly/
2) Авторизуйтесь:
```bash
fly auth login
```
3) Инициализируйте приложение (одноразово):
```bash
fly launch --name tutor-search302 --no-deploy
```

4) В `fly.toml` (в корне репозитория) уже настроены порты и стандартные параметры.
5) Задайте необходимые секреты:
```bash
fly secrets set SECRET_KEY="ваш_секрет" FLASK_ENV=production
```

6) Разверните приложение:
```bash
fly deploy
```

После успешного выката Fly выдаст URL вроде `https://tutor-search302.fly.dev`.

### 🟢 Если хотите разместить на Heroku
1) Установите [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2) В корне проекта выполните:
```bash
heroku create
heroku config:set SECRET_KEY=... DATABASE_URL=postgres://... FLASK_ENV=production
git push heroku main
```

> Для Heroku используется `Procfile`, который уже добавлен в репозиторий.

## 📝 API Документация

### Аутентификация
- `POST /api/auth/register` - Регистрация пользователя
- `POST /api/auth/login` - Вход пользователя
- `POST /api/auth/logout` - Выход пользователя

### Репетиторы
- `GET /api/tutors` - Получение списка репетиторов
- `POST /api/become-tutor` - Стать репетитором

### Курсы
- `GET /api/courses` - Получение списка курсов
- `POST /api/enroll/<course_id>` - Запись на курс

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit ваши изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. файл LICENSE для деталей.

## 📞 Поддержка

Если у вас есть вопросы или проблемы, пожалуйста:
- Создайте Issue в репозитории
- Свяжитесь с поддержкой по email: support@edunext.com

## 🔄 Обновления

### Версия 1.1.0 (текущая)
- ✅ Улучшенная безопасность (CSRF, валидация)
- ✅ Новые обработчики ошибок
- ✅ Улучшенный UI/UX дизайн
- ✅ Toast уведомления
- ✅ Мета-теги для SEO
- ✅ Логирование запросов

### Планируемые улучшения
- 🔄 Redis для сессий и кэширования
- 🔄 Email уведомления
- 🔄 Онлайн-оплата
- 🔄 Видео-звонки
- 🔄 Мобильное приложение
