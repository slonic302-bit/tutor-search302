import os
import json
import traceback
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, redirect, url_for, abort, session
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_cors import CORS
import logging
import re
import secrets
import uuid
from sqlalchemy import inspect, text

app = Flask(__name__)
CORS(app)  # Включаем CORS для API
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///app_new.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)  # Сессия живет 7 дней

# Настройки для загрузки файлов
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB максимальный размер файла
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Создаем папку для загрузки, если её нет
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'index'

# Связь репетитор — предметы (многие ко многим)
tutor_subjects = db.Table('tutor_subjects',
    db.Column('tutor_id', db.Integer, db.ForeignKey('tutor_profile.id'), primary_key=True),
    db.Column('subject_id', db.Integer, db.ForeignKey('subject.id'), primary_key=True)
)


class TutorApplication(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    education = db.Column(db.Text, nullable=True)
    experience = db.Column(db.Text, nullable=True)
    subjects = db.Column(db.Text, nullable=True)  # JSON строка с предметами
    hourly_rate = db.Column(db.Integer, nullable=True)
    about = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    admin_notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    reviewed_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    user = db.relationship('User', foreign_keys=[user_id], backref='tutor_applications')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by], backref='reviewed_applications')


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(120), nullable=True)
    role = db.Column(db.String(20), default='student')
    is_admin = db.Column(db.Boolean, default=False)
    points = db.Column(db.Integer, default=0)
    grade = db.Column(db.String(20), nullable=True)  # 5 класс, 10 класс и т.д.
    learning_goal = db.Column(db.String(200), nullable=True)  # ЕГЭ, ОГЭ, улучшить оценки
    referral_code = db.Column(db.String(36), unique=True, nullable=True)
    referred_by_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    tutor_profile = db.relationship('TutorProfile', backref='user', uselist=False)
    enrollments = db.relationship('Enrollment', backref='student', lazy=True)
    referrals = db.relationship('User', backref=db.backref('referred_by_user', remote_side=[id]), lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    slug = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(300), nullable=True)
    icon = db.Column(db.String(50), default='📚')

    courses = db.relationship('Course', backref='subject', lazy=True)


class TutorProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, unique=True)
    bio = db.Column(db.Text, nullable=True)
    hourly_rate = db.Column(db.Integer, default=0)  # руб/час
    experience_years = db.Column(db.Integer, default=0)
    education = db.Column(db.String(200), nullable=True)
    is_approved = db.Column(db.Boolean, default=False)
    photo_url = db.Column(db.String(500), nullable=True)  # URL фотографии
    
    subjects = db.relationship('Subject', secondary=tutor_subjects, backref=db.backref('tutors', lazy='dynamic'))
    courses = db.relationship('Course', backref='tutor', lazy=True)
    reviews = db.relationship('Review', backref='tutor', lazy=True)


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    tutor_id = db.Column(db.Integer, db.ForeignKey('tutor_profile.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Integer, default=0)
    duration_weeks = db.Column(db.Integer, default=8)
    level = db.Column(db.String(50), default='Начальный')
    installments_months = db.Column(db.Integer, default=0)

    enrollments = db.relationship('Enrollment', backref='course', lazy=True)
    # Удалена неправильная связь с lessons


class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    progress = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint('user_id', 'course_id', name='unique_enrollment'),)


class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tutor_id = db.Column(db.Integer, db.ForeignKey('tutor_profile.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    text = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship('User', backref='reviews')


class Lesson(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    enrollment_id = db.Column(db.Integer, db.ForeignKey('enrollment.id'), nullable=False)
    scheduled_at = db.Column(db.DateTime, nullable=False)
    duration_minutes = db.Column(db.Integer, default=60)
    completed = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text, nullable=True)
    
    # Правильные связи
    enrollment = db.relationship('Enrollment', backref='lessons')


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_at = db.Column(db.DateTime, nullable=True)


class PasswordResetToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    token = db.Column(db.String(64), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


def init_default_data():
    # Предметы
    if Subject.query.count() == 0:
        defaults = [
            ('Математика', 'math', 'Алгебра, геометрия, подготовка к ЕГЭ/ОГЭ', '📐'),
            ('Русский язык', 'russian', 'Грамматика, сочинения, подготовка к экзаменам', '📝'),
            ('Физика', 'physics', 'Механика, оптика, электричество', '⚛️'),
            ('Химия', 'chemistry', 'Органическая и неорганическая химия', '🧪'),
            ('Информатика', 'informatics', 'Программирование, алгоритмы', '💻'),
            ('Английский язык', 'english', 'Грамматика, разговорный, подготовка к ЕГЭ', '🌍'),
            ('Биология', 'biology', 'Ботаника, зоология, анатомия', '🧬'),
            ('История', 'history', 'Всемирная и отечественная история', '📜'),
            ('Обществознание', 'social', 'Обществознание, право', '🏛️'),
        ]
        for name, slug, desc, icon in defaults:
            db.session.add(Subject(name=name, slug=slug, description=desc, icon=icon))
        db.session.commit()


def validate_csrf_token():
    """Проверка CSRF токена для POST запросов"""
    if request.method == 'POST':
        token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
        if not token or token != session.get('csrf_token'):
            return False
    return True

def generate_csrf_token():
    """Генерация CSRF токена"""
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_urlsafe(32)
    return session['csrf_token']

def validate_email(email):
    """Валидация email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def validate_password(password):
    """Валидация пароля - минимальные требования"""
    return len(password) >= 6

@app.before_request
def before_request():
    """Логирование запросов"""
    logger.info(f'{request.method} {request.path}')

def _table_has_column(table_name: str, column_name: str) -> bool:
    """Проверка наличия столбца в таблице через SQLAlchemy Inspector."""
    try:
        inspector = inspect(db.engine)
        cols = inspector.get_columns(table_name)
        return any(c['name'] == column_name for c in cols)
    except Exception:
        return False


def ensure_database():
    """Создаёт базу и заполняет её данными при старте сервера."""
    try:
        db.create_all()
        init_default_data()

        # Если в таблице нет нужных колонок (например, при обновлении из старой версии) — добавляем
        with db.engine.connect() as conn:
            if not _table_has_column('user', 'referral_code'):
                try:
                    conn.execute(text("ALTER TABLE user ADD COLUMN referral_code VARCHAR(36)"))
                    conn.commit()
                except Exception:
                    conn.rollback()
            if not _table_has_column('user', 'referred_by_id'):
                try:
                    conn.execute(text("ALTER TABLE user ADD COLUMN referred_by_id INTEGER"))
                    conn.commit()
                except Exception:
                    conn.rollback()

        # Убедимся, что каждый пользователь имеет referral_code (для реферальной ссылки)
        if _table_has_column('user', 'referral_code'):
            users_without_code = User.query.filter(
                (User.referral_code == None) | (User.referral_code == '')
            ).all()
            for u in users_without_code:
                u.referral_code = str(uuid.uuid4())
            if users_without_code:
                db.session.commit()

    except Exception as e:
        logger.warning(f'Failed to initialize database: {e}')

@app.errorhandler(500)
def internal_error(e):
    """Обработка внутренних ошибок"""
    logger.error(f'Internal error: {str(e)}')
    return jsonify({'error': 'Внутренняя ошибка сервера'}), 500

@app.errorhandler(400)
def bad_request(e):
    """Обработка ошибок запроса"""
    return jsonify({'error': 'Неверный запрос'}), 400

@app.context_processor
def inject_csrf_token():
    """Добавление CSRF токена во все шаблоны"""
    return {'csrf_token': generate_csrf_token()}

# === Страницы ===
@app.route('/')
def index():
    subjects = Subject.query.all()
    tutors = TutorProfile.query.filter_by(is_approved=True).limit(6).all()
    courses = Course.query.limit(6).all()
    return render_template('index.html', subjects=subjects, tutors=tutors, courses=courses)


@app.route('/subjects')
def subjects_page():
    subjects = Subject.query.all()
    return render_template('subjects.html', subjects=subjects)


@app.route('/tutors')
def tutors_page():
    subject_id = request.args.get('subject')
    q = request.args.get('q', '').strip()
    min_rate = request.args.get('min_rate', type=int)
    max_rate = request.args.get('max_rate', type=int)
    tutors = TutorProfile.query.filter_by(is_approved=True)
    if subject_id:
        tutors = tutors.join(tutor_subjects).filter(tutor_subjects.c.subject_id == subject_id)
    if q:
        tutors = tutors.join(User, TutorProfile.user_id == User.id).filter(
            db.or_(User.name.ilike(f'%{q}%'), TutorProfile.bio.ilike(f'%{q}%'))
        )
    if min_rate is not None:
        tutors = tutors.filter(TutorProfile.hourly_rate >= min_rate)
    if max_rate is not None:
        tutors = tutors.filter(TutorProfile.hourly_rate <= max_rate)
    tutors = tutors.all()
    subjects = Subject.query.all()
    return render_template('tutors.html', tutors=tutors, subjects=subjects,
                          selected_subject=subject_id, search_q=q, min_rate=min_rate, max_rate=max_rate)


@app.route('/tutor/<int:id>')
def tutor_page(id):
    tutor = TutorProfile.query.get_or_404(id)
    if not tutor.is_approved:
        return redirect(url_for('tutors_page'))
    courses = Course.query.filter_by(tutor_id=id).all()
    reviews = Review.query.filter_by(tutor_id=id).order_by(Review.created_at.desc()).limit(10).all()
    avg_rating = db.session.query(db.func.avg(Review.rating)).filter_by(tutor_id=id).scalar() or 0
    reviews_count = Review.query.filter_by(tutor_id=id).count()
    return render_template('tutor.html', tutor=tutor, courses=courses,
                          reviews=reviews, avg_rating=float(avg_rating), reviews_count=reviews_count)


@app.route('/courses')
def courses_page():
    subject_id = request.args.get('subject')
    q_str = request.args.get('q', '').strip()
    min_price = request.args.get('min_price', type=int)
    max_price = request.args.get('max_price', type=int)
    q = Course.query
    if subject_id:
        q = q.filter_by(subject_id=subject_id)
    if q_str:
        q = q.filter(db.or_(Course.title.ilike(f'%{q_str}%'), Course.description.ilike(f'%{q_str}%')))
    if min_price is not None:
        q = q.filter(Course.price >= min_price)
    if max_price is not None:
        q = q.filter(Course.price <= max_price)
    courses = q.all()
    subjects = Subject.query.all()
    return render_template('courses.html', courses=courses, subjects=subjects,
                          selected_subject=subject_id, search_q=q_str, min_price=min_price, max_price=max_price)


@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html')


@app.route('/become-tutor')
@login_required
def become_tutor_page():
    if TutorProfile.query.filter_by(user_id=current_user.id).first():
        return redirect(url_for('profile'))
    subjects = Subject.query.all()
    return render_template('become_tutor.html', subjects=subjects)


@app.route('/admin')
@admin_required
def admin():
    subjects = Subject.query.all()
    tutors = TutorProfile.query.all()
    courses = Course.query.all()
    users = User.query.all()
    return render_template('admin.html', subjects=subjects, tutors=tutors, courses=courses, users=users)


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/tutor-dashboard')
@login_required
def tutor_dashboard():
    tp = TutorProfile.query.filter_by(user_id=current_user.id).first()
    if not tp:
        return redirect(url_for('profile'))
    enrollments = Enrollment.query.join(Course).filter(Course.tutor_id == tp.id).all()
    students = [e.student for e in enrollments]
    total_earnings = sum(c.price for c in tp.courses for _ in c.enrollments)
    lessons = Lesson.query.join(Enrollment).join(Course).filter(Course.tutor_id == tp.id).order_by(Lesson.scheduled_at.desc()).limit(10).all()
    return render_template('tutor_dashboard.html', tutor=tp, enrollments=enrollments, lessons=lessons, total_earnings=total_earnings)


@app.route('/messages')
@login_required
def messages_page():
    return render_template('messages.html')


@app.route('/forgot-password')
def forgot_password_page():
    return render_template('forgot_password.html')


@app.route('/reset-password/<token>')
def reset_password_page(token):
    return render_template('reset_password.html', token=token)


# === API ===
@app.route('/api/profile')
def api_profile():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Не авторизован'}), 401
    enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
    courses_data = []
    for e in enrollments:
        c = e.course
        courses_data.append({
            'id': c.id, 'title': c.title, 'progress': e.progress,
            'date': e.created_at.strftime('%d.%m.%Y') if e.created_at else ''
        })
    # Рекомендации курсов (по цели обучения)
    goal = (getattr(current_user, 'learning_goal', '') or '').lower()
    recommended = []
    if 'егэ' in goal:
        recommended = Course.query.join(Subject).filter(
            db.or_(Course.title.ilike('%ЕГЭ%'), Subject.name.ilike('%ЕГЭ%'))
        ).limit(6).all()
    elif 'огэ' in goal:
        recommended = Course.query.join(Subject).filter(
            db.or_(Course.title.ilike('%ОГЭ%'), Subject.name.ilike('%ОГЭ%'))
        ).limit(6).all()
    else:
        recommended = Course.query.order_by(Course.id.desc()).limit(6).all()

    recommended_courses = [
        {
            'id': c.id,
            'title': c.title,
            'subject': c.subject.name,
            'tutor': c.tutor.user.name,
            'price': c.price
        }
        for c in recommended
    ]

    referral_code = current_user.referral_code or ''
    referral_link = ''
    if referral_code:
        referral_link = request.url_root.rstrip('/') + '/?ref=' + referral_code

    return jsonify({
        'user': {
            'id': current_user.id, 'email': current_user.email,
            'name': current_user.name or '', 'points': current_user.points or 0,
            'grade': getattr(current_user, 'grade', None) or '',
            'learning_goal': getattr(current_user, 'learning_goal', None) or '',
            'is_tutor': current_user.tutor_profile is not None,
            'referral_code': referral_code,
            'referral_link': referral_link,
            'referral_count': current_user.referrals.count(),
        },
        'courses': courses_data,
        'recommended_courses': recommended_courses
    })


@app.route('/api/profile', methods=['PUT', 'PATCH'])
def api_profile_update():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Не авторизован'}), 401
    data = request.get_json() or {}
    if 'grade' in data:
        current_user.grade = data.get('grade') or None
    if 'learning_goal' in data:
        current_user.learning_goal = data.get('learning_goal') or None
    if 'name' in data:
        current_user.name = data.get('name') or None
    db.session.commit()
    return jsonify({'ok': True})


@app.route('/api/subjects')
def api_subjects():
    subjects = [{'id': s.id, 'name': s.name, 'slug': s.slug, 'icon': s.icon} for s in Subject.query.all()]
    return jsonify(subjects)


@app.route('/api/tutors')
def api_tutors():
    subject_id = request.args.get('subject_id', type=int)
    tutors = TutorProfile.query.filter_by(is_approved=True)
    if subject_id:
        tutors = tutors.join(tutor_subjects).filter(tutor_subjects.c.subject_id == subject_id)
    result = []
    for t in tutors.all():
        result.append({
            'id': t.id, 'name': t.user.name or 'Репетитор',
            'subjects': [s.name for s in t.subjects],
            'hourly_rate': t.hourly_rate, 'bio': (t.bio or '')[:150]
        })
    return jsonify(result)


@app.route('/api/courses')
def api_courses():
    subject_id = request.args.get('subject_id', type=int)
    q = Course.query
    if subject_id:
        q = q.filter_by(subject_id=subject_id)
    result = []
    for c in q.all():
        result.append({
            'id': c.id, 'title': c.title, 'price': c.price,
            'subject': c.subject.name, 'tutor': c.tutor.user.name
        })
    return jsonify(result)


@app.route('/api/become-tutor', methods=['POST'])
def api_become_tutor():
    try:
        if not current_user.is_authenticated:
            return jsonify({'error': 'Войдите в аккаунт'}), 401
        if TutorProfile.query.filter_by(user_id=current_user.id).first():
            return jsonify({'error': 'У вас уже есть профиль репетитора'}), 400
            
        data = request.get_json() or {}
        bio = data.get('bio', '').strip()
        hourly_rate = int(data.get('hourly_rate', 0) or 0)
        experience_years = int(data.get('experience_years', 0) or 0)
        education = data.get('education', '').strip()
        subject_ids = data.get('subject_ids', [])
        
        # Валидация
        if hourly_rate < 0 or hourly_rate > 10000:
            return jsonify({'error': 'Укажите корректную почасовую ставку'}), 400
            
        if experience_years < 0 or experience_years > 50:
            return jsonify({'error': 'Укажите корректный опыт работы'}), 400
            
        if not subject_ids:
            return jsonify({'error': 'Выберите хотя бы один предмет'}), 400
            
        tp = TutorProfile(
            user_id=current_user.id,
            bio=bio or None,
            hourly_rate=hourly_rate,
            experience_years=experience_years,
            education=education or None,
            is_approved=False
        )
        db.session.add(tp)
        current_user.role = 'tutor'
        
        for sid in subject_ids:
            s = Subject.query.get(sid)
            if s:
                tp.subjects.append(s)
        db.session.commit()
        logger.info(f'Tutor application submitted: {current_user.email}')
        return jsonify({'ok': True, 'message': 'Заявка отправлена. Ожидайте одобрения администратора.'})
    except ValueError:
        return jsonify({'error': 'Неверный формат данных'}), 400
    except Exception as e:
        logger.error(f'Tutor application error: {str(e)}')
        return jsonify({'error': 'Ошибка подачи заявки'}), 500


@app.route('/api/review/<int:tutor_id>', methods=['POST'])
def api_add_review(tutor_id):
    if not current_user.is_authenticated:
        return jsonify({'error': 'Войдите в аккаунт'}), 401
    tutor = TutorProfile.query.get_or_404(tutor_id)
    data = request.get_json() or {}
    rating = int(data.get('rating', 0))
    if rating < 1 or rating > 5:
        return jsonify({'error': 'Рейтинг от 1 до 5'}), 400
    r = Review(tutor_id=tutor_id, user_id=current_user.id, rating=rating, text=data.get('text'))
    db.session.add(r)
    db.session.commit()
    return jsonify({'ok': True})


@app.route('/api/lessons', methods=['POST'])
@login_required
def api_add_lesson():
    data = request.get_json() or {}
    enrollment_id = data.get('enrollment_id')
    scheduled_at = data.get('scheduled_at')
    if not enrollment_id or not scheduled_at:
        return jsonify({'error': 'Укажите enrollment_id и scheduled_at'}), 400
    e = Enrollment.query.get_or_404(enrollment_id)
    if e.course.tutor.user_id != current_user.id:
        return jsonify({'error': 'Нет доступа'}), 403
    if isinstance(scheduled_at, str):
        try:
            dt = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00'))
        except ValueError:
            dt = datetime.strptime(scheduled_at[:16], '%Y-%m-%dT%H:%M')
    else:
        dt = scheduled_at
    lesson = Lesson(enrollment_id=enrollment_id, scheduled_at=dt, duration_minutes=data.get('duration_minutes', 60))
    db.session.add(lesson)
    db.session.commit()
    return jsonify({'ok': True, 'id': lesson.id})


@app.route('/api/messages')
@login_required
def api_messages():
    user_id = current_user.id
    with_user = request.args.get('with_user', type=int)
    msgs = Message.query.filter(
        db.or_(
            db.and_(Message.sender_id == user_id, Message.receiver_id == with_user),
            db.and_(Message.sender_id == with_user, Message.receiver_id == user_id)
        )
    ).order_by(Message.created_at).all() if with_user else []
    return jsonify([{'id': m.id, 'sender_id': m.sender_id, 'text': m.text,
                    'created_at': m.created_at.isoformat() if m.created_at else None} for m in msgs])


@app.route('/api/messages', methods=['POST'])
@login_required
def api_send_message():
    data = request.get_json() or {}
    receiver_id = data.get('receiver_id')
    text = (data.get('text') or '').strip()
    if not receiver_id or not text:
        return jsonify({'error': 'Укажите receiver_id и text'}), 400
    m = Message(sender_id=current_user.id, receiver_id=receiver_id, text=text)
    db.session.add(m)
    db.session.commit()
    return jsonify({'ok': True, 'id': m.id})


@app.route('/api/forgot-password', methods=['POST'])
def api_forgot_password():
    import secrets
    data = request.get_json() or {}
    email = (data.get('email') or '').strip()
    if not email:
        return jsonify({'error': 'Укажите email'}), 400
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'ok': True})  # не раскрываем наличие email
    token = secrets.token_urlsafe(32)
    expires = datetime.utcnow() + timedelta(hours=24)
    prt = PasswordResetToken(user_id=user.id, token=token, expires_at=expires)
    db.session.add(prt)
    db.session.commit()
    # В продакшене отправить email. Сейчас возвращаем ссылку для теста
    reset_url = url_for('reset_password_page', token=token, _external=True)
    return jsonify({'ok': True, 'reset_url': reset_url})


@app.route('/api/reset-password', methods=['POST'])
def api_reset_password():
    data = request.get_json() or {}
    token = (data.get('token') or '').strip()
    password = data.get('password', '')
    if not token or not password:
        return jsonify({'error': 'Укажите токен и новый пароль'}), 400
    prt = PasswordResetToken.query.filter_by(token=token).first()
    if not prt or prt.expires_at < datetime.utcnow():
        return jsonify({'error': 'Ссылка недействительна или истекла'}), 400
    prt.user.set_password(password)
    db.session.delete(prt)
    db.session.commit()
    return jsonify({'ok': True})


@app.route('/api/enroll/<int:course_id>', methods=['POST'])
def api_enroll(course_id):
    if not current_user.is_authenticated:
        return jsonify({'error': 'Войдите в аккаунт'}), 401
    course = Course.query.get_or_404(course_id)
    existing = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if existing:
        return jsonify({'error': 'Вы уже записаны на этот курс'}), 400
    e = Enrollment(user_id=current_user.id, course_id=course_id)
    db.session.add(e)
    db.session.commit()
    return jsonify({'ok': True})


# Загрузка фотографии репетитора
@app.route('/api/tutor/upload-photo', methods=['POST'])
@login_required
def upload_tutor_photo():
    try:
        # Проверяем, есть ли у пользователя профиль репетитора
        tutor_profile = TutorProfile.query.filter_by(user_id=current_user.id).first()
        if not tutor_profile:
            # Если профиля нет, создаем его
            tutor_profile = TutorProfile(user_id=current_user.id)
            db.session.add(tutor_profile)
            db.session.commit()
        
        # Проверяем, есть ли файл в запросе
        if 'photo' not in request.files:
            return jsonify({'error': 'Файл не найден'}), 400
        
        file = request.files['photo']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        # Проверяем тип файла
        if not allowed_file(file.filename):
            return jsonify({'error': 'Разрешены только файлы: png, jpg, jpeg, gif'}), 400
        
        # Создаем безопасное имя файла
        filename = secure_filename(file.filename)
        # Добавляем уникальный префикс
        unique_filename = f"tutor_{current_user.id}_{int(datetime.utcnow().timestamp())}_{filename}"
        
        # Сохраняем файл
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        
        # Обновляем профиль репетитора
        tutor_profile.photo_url = f"/static/uploads/{unique_filename}"
        db.session.commit()
        
        logger.info(f"Photo uploaded for tutor {current_user.id}: {unique_filename}")
        
        return jsonify({
            'ok': True,
            'photo_url': tutor_profile.photo_url
        })
        
    except Exception as e:
        import traceback
        logger.error(f"Photo upload error: {str(e)}")
        logger.error(f"Photo upload traceback: {traceback.format_exc()}")
        return jsonify({'error': 'Ошибка загрузки фотографии'}), 500


# Тестовая страница входа
@app.route('/test-login')
def test_login():
    return render_template('test_login.html')


# Полная проверка сайта
@app.route('/full-test')
def full_test():
    return render_template('full_test.html')


# Админ-панель
@app.route('/admin')
@login_required
def admin_panel():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    return render_template('admin.html')


# Отладочный эндпоинт для проверки админа
@app.route('/debug-admin')
def debug_admin():
    try:
        admin = User.query.filter_by(email='edunext@admin.com').first()
        if admin:
            return jsonify({
                'exists': True,
                'email': admin.email,
                'name': admin.name,
                'is_admin': admin.is_admin,
                'password_check': admin.check_password('admin2026')
            })
        else:
            return jsonify({'exists': False, 'message': 'Администратор не найден'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Создание админа
@app.route('/create-admin')
def create_admin():
    try:
        # Проверяем, существует ли администратор
        existing_admin = User.query.filter_by(email='edunext@admin.com').first()
        if existing_admin:
            return jsonify({
                'message': 'Администратор уже существует',
                'email': 'edunext@admin.com',
                'password': 'admin2026'
            })
        
        # Создаем нового админа
        admin = User(
            email='edunext@admin.com',
            name='EduNext Administrator',
            is_admin=True,
            role='admin'
        )
        admin.set_password('admin2026')  # Пароль: admin2026
        
        db.session.add(admin)
        db.session.commit()
        
        logger.info('Admin account created successfully')
        return jsonify({
            'message': 'Администратор создан успешно',
            'email': 'edunext@admin.com',
            'password': 'admin2026'
        })
    except Exception as e:
        logger.error(f'Error creating admin: {str(e)}')
        return jsonify({'error': 'Ошибка создания администратора'}), 500


# Tutor Applications
@app.route('/become-tutor', methods=['GET', 'POST'])
def become_tutor():
    if request.method == 'GET':
        subjects = Subject.query.all()
        return render_template('become_tutor.html', subjects=subjects)
    
    try:
        data = request.get_json() or {}
        name = data.get('name', '').strip()
        email = data.get('email', '').strip()
        phone = data.get('phone', '').strip()
        education = data.get('education', '').strip()
        experience = data.get('experience', '').strip()
        subjects_selected = data.get('subjects', [])
        hourly_rate = data.get('hourly_rate')
        about = data.get('about', '').strip()
        
        # Валидация
        if not name or not email:
            return jsonify({'error': 'Имя и email обязательны'}), 400
            
        if not validate_email(email):
            return jsonify({'error': 'Введите корректный email'}), 400
        
        # Создание заявки
        application = TutorApplication(
            user_id=current_user.id if current_user.is_authenticated else None,
            name=name,
            email=email,
            phone=phone or None,
            education=education or None,
            experience=experience or None,
            subjects=json.dumps(subjects_selected) if subjects_selected else None,
            hourly_rate=hourly_rate or None,
            about=about or None,
            status='pending'
        )
        
        db.session.add(application)
        db.session.commit()
        
        logger.info(f'New tutor application from {email}')
        return jsonify({'ok': True, 'message': 'Заявка отправлена на рассмотрение'})
        
    except Exception as e:
        logger.error(f'Tutor application error: {str(e)}')
        return jsonify({'error': 'Ошибка отправки заявки'}), 500


@app.route('/api/tutor-applications', methods=['GET'])
def api_tutor_applications():
    # Временно уберем проверку админа для теста
    # if not current_user.is_admin:
    #     return jsonify({'error': 'Доступ запрещен'}), 403
        
    applications = TutorApplication.query.order_by(TutorApplication.created_at.desc()).all()
    result = []
    for app in applications:
        result.append({
            'id': app.id,
            'name': app.name,
            'email': app.email,
            'phone': app.phone,
            'education': app.education,
            'experience': app.experience,
            'subjects': json.loads(app.subjects) if app.subjects else [],
            'hourly_rate': app.hourly_rate,
            'about': app.about,
            'status': app.status,
            'admin_notes': app.admin_notes,
            'created_at': app.created_at.isoformat(),
            'reviewed_at': app.reviewed_at.isoformat() if app.reviewed_at else None
        })
    return jsonify(result)


@app.route('/api/tutor-applications/<int:app_id>/review', methods=['POST'])
def api_review_application(app_id):
    # Временно уберем проверку админа для теста
    data = request.get_json() or {}
    status = data.get('status')
    admin_notes = data.get('admin_notes', '').strip()
    
    if status not in ['approved', 'rejected']:
        return jsonify({'error': 'Неверный статус'}), 400
        
    application = TutorApplication.query.get_or_404(app_id)
    application.status = status
    application.admin_notes = admin_notes or None
    application.reviewed_at = datetime.utcnow()
    application.reviewed_by = current_user.id if current_user.is_authenticated else None
    
    db.session.commit()
    
    logger.info(f'Application {app_id} {status}')
    return jsonify({'ok': True})


# Auth
@app.route('/api/auth/register', methods=['POST'])
def api_register():
    try:
        data = request.get_json() or {}
        email = data.get('email', '').strip()
        password = data.get('password', '')
        name = data.get('name', '').strip()
        ref_code = data.get('ref') or data.get('referral')
        
        # Валидация
        if not email or not password:
            return jsonify({'error': 'Email и пароль обязательны'}), 400
        
        if not validate_email(email):
            return jsonify({'error': 'Введите корректный email'}), 400
            
        if not validate_password(password):
            return jsonify({'error': 'Пароль должен содержать минимум 6 символов'}), 400
            
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'Пользователь с таким email уже существует'}), 400
            
        user = User(email=email, name=name or None)
        user.set_password(password)
        user.referral_code = str(uuid.uuid4())

        if ref_code:
            referrer = User.query.filter_by(referral_code=ref_code).first()
            if referrer:
                user.referred_by_id = referrer.id

        db.session.add(user)
        db.session.commit()
        login_user(user)
        logger.info(f'New user registered: {email}')
        return jsonify({'ok': True})
    except Exception as e:
        logger.error(f'Registration error: {str(e)}')
        return jsonify({'error': 'Ошибка регистрации'}), 500


@app.route('/api/auth/login', methods=['POST'])
def api_login():
    try:
        data = request.get_json() or {}
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        logger.info(f"Login attempt: {email}")
        
        if not email or not password:
            logger.warning("Empty email or password")
            return jsonify({'error': 'Введите email и пароль'}), 400
            
        user = User.query.filter_by(email=email).first()
        logger.info(f"User found: {user is not None}")
        
        if not user:
            logger.warning(f"User not found: {email}")
            return jsonify({'error': 'Неверный email или пароль'}), 401
            
        password_check = user.check_password(password)
        logger.info(f"Password check: {password_check}")
        
        if not password_check:
            logger.warning(f"Invalid password for: {email}")
            return jsonify({'error': 'Неверный email или пароль'}), 401
            
        logger.info(f"Logging in user: {email}")
        login_user(user)
        logger.info(f"User logged in: {email}")
        
        return jsonify({'ok': True})
        
    except Exception as e:
        import traceback
        logger.error(f"Login error: {str(e)}")
        logger.error(f"Login traceback: {traceback.format_exc()}")
        return jsonify({'error': f'Ошибка входа: {str(e)}'}), 500


@app.route('/api/auth/logout', methods=['POST'])
def api_logout():
    try:
        logger.info("Logout API called")
        logout_user()
        # Очищаем сессию полностью
        session.clear()
        logger.info("User logged out successfully")
        return jsonify({'ok': True})
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        return jsonify({'error': 'Ошибка выхода'}), 500


# Admin API
@app.route('/api/admin/subject', methods=['POST'])
@admin_required
def api_add_subject():
    data = request.get_json() or {}
    name = data.get('name', '').strip()
    slug = data.get('slug', '').strip() or name.lower().replace(' ', '-')
    if not name:
        return jsonify({'error': 'Укажите название'}), 400
    s = Subject(name=name, slug=slug, description=data.get('description'), icon=data.get('icon', '📚'))
    db.session.add(s)
    db.session.commit()
    return jsonify({'ok': True, 'id': s.id})


@app.route('/api/admin/tutor', methods=['POST'])
@admin_required
def api_add_tutor():
    data = request.get_json() or {}
    user_id = data.get('user_id')
    subject_ids = data.get('subject_ids', [])
    if not user_id:
        return jsonify({'error': 'Укажите user_id'}), 400
    user = User.query.get_or_404(user_id)
    if TutorProfile.query.filter_by(user_id=user_id).first():
        return jsonify({'error': 'У пользователя уже есть профиль репетитора'}), 400
    tp = TutorProfile(
        user_id=user_id,
        bio=data.get('bio'),
        hourly_rate=data.get('hourly_rate', 0),
        experience_years=data.get('experience_years', 0),
        education=data.get('education'),
        is_approved=data.get('is_approved', True)
    )
    db.session.add(tp)
    db.session.commit()
    for sid in subject_ids:
        subj = Subject.query.get(sid)
        if subj:
            tp.subjects.append(subj)
    user.role = 'tutor'
    db.session.commit()
    return jsonify({'ok': True, 'id': tp.id})


@app.route('/api/admin/users')
def api_users():
    # Временно уберем проверку админа для теста
    users = [{'id': u.id, 'email': u.email, 'name': u.name, 'role': u.role} for u in User.query.all()]
    return jsonify(users)


@app.route('/api/admin/tutor/<int:id>/approve', methods=['POST'])
def api_approve_tutor(id):
    # Временно уберем проверку админа для теста
    t = TutorProfile.query.get_or_404(id)
    t.is_approved = True
    db.session.commit()
    return jsonify({'ok': True})


@app.route('/api/admin/course', methods=['POST'])
def api_add_course():
    # Временно уберем проверку админа для теста
    data = request.get_json() or {}
    subject_id = data.get('subject_id')
    tutor_id = data.get('tutor_id')
    title = data.get('title', '').strip()
    if not all([subject_id, tutor_id, title]):
        return jsonify({'error': 'Укажите предмет, репетитора и название курса'}), 400
    c = Course(
        subject_id=subject_id, tutor_id=tutor_id, title=title,
        description=data.get('description'),
        price=data.get('price', 0), duration_weeks=data.get('duration_weeks', 8),
        level=data.get('level', 'Начальный'),
        installments_months=data.get('installments_months', 0)
    )
    db.session.add(c)
    db.session.commit()
    return jsonify({'ok': True, 'id': c.id})


@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404


def upgrade_db():
    """Миграции для старой БД"""
    from sqlalchemy import text
    with db.engine.connect() as conn:
        for col, stmt in [
            ('role', "ALTER TABLE user ADD COLUMN role VARCHAR(20) DEFAULT 'student'"),
            ('grade', "ALTER TABLE user ADD COLUMN grade VARCHAR(20)"),
            ('learning_goal', "ALTER TABLE user ADD COLUMN learning_goal VARCHAR(200)"),
            ('referral_code', "ALTER TABLE user ADD COLUMN referral_code VARCHAR(36) UNIQUE"),
            ('referred_by_id', "ALTER TABLE user ADD COLUMN referred_by_id INTEGER"),
            ('installments', "ALTER TABLE course ADD COLUMN installments_months INTEGER DEFAULT 0"),
        ]:
            try:
                conn.execute(text(stmt))
                conn.commit()
            except Exception:
                conn.rollback()


if __name__ == '__main__':
    with app.app_context():
        ensure_database()
        try:
            upgrade_db()
        except Exception:
            pass

    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV', '').lower() == 'development'
    app.run(debug=debug, host='0.0.0.0', port=port)

# Ensure database exists when importing app (e.g., for WSGI servers)
with app.app_context():
    ensure_database()
