"""Скрипт для создания демо-данных: админ, репетитор, курс.
Запуск: python seed_demo.py
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, db, User, Subject, TutorProfile, Course
from werkzeug.security import generate_password_hash

def seed():
    with app.app_context():
        # Первый админ (если нет ни одного)
        if not User.query.filter_by(is_admin=True).first():
            admin = User.query.filter_by(email='admin@edunext.ru').first()
            if not admin:
                admin = User(
                    email='admin@edunext.ru',
                    name='Администратор',
                    role='admin',
                    is_admin=True
                )
                admin.password_hash = generate_password_hash('admin123')
                db.session.add(admin)
                db.session.commit()
                print('Создан админ: admin@edunext.ru / admin123')

            # Первый одобренный репетитор
            if not TutorProfile.query.filter_by(is_approved=True).first():
                tp = TutorProfile.query.filter_by(user_id=admin.id).first()
                if not tp:
                    math = Subject.query.filter_by(slug='math').first()
                    if math:
                        tp = TutorProfile(
                            user_id=admin.id,
                            bio='Опытный репетитор по математике. Подготовка к ЕГЭ и ОГЭ.',
                            hourly_rate=1500,
                            experience_years=5,
                            education='МГУ, мехмат',
                            is_approved=True
                        )
                        db.session.add(tp)
                        db.session.commit()
                        tp.subjects.append(math)
                        db.session.commit()

                        # Демо-курс
                        c = Course(
                            subject_id=math.id, tutor_id=tp.id,
                            title='Математика: подготовка к ЕГЭ',
                            description='Комплексная подготовка к экзамену. Алгебра и геометрия.',
                            price=12000, duration_weeks=12, level='Средний'
                        )
                        db.session.add(c)
                        db.session.commit()
                        print('Создан репетитор и демо-курс')
        print('Готово.')

if __name__ == '__main__':
    seed()
